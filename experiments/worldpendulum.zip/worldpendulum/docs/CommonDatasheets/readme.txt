Datasheets related with components and devices that could be used 
in more than one experiments. If the datasheet is related only 
with a particular experiment should be moved to  \Apparatus\Docs.