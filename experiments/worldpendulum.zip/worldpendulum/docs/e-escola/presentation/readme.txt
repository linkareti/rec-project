Presentations related with the subject of the experiment; 
it should contain original material to be treated by teachers 
as support material for lessons.