Reports and data analysis of each experiments. 
Can be .xls, .doc, .pdf etc.