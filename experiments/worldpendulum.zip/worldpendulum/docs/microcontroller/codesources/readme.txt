Repository of .zip files containing all source and libs necessary 
for compiling running code on the experiment microcontroller.