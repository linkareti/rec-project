General locations for documents related with the experiment 
like protocols (originals from producers), apparatus descriptions, 
specific datasheets, etc.