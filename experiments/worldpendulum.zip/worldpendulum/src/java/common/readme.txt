The common code for this experiment (both client and server shared). 
You may extend the platform base code both from eLab and ReC 
as needed, but the sources should be located here for build
system correct integration.
