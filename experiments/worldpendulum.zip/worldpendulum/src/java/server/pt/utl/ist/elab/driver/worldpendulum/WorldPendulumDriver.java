/* 
 * DiscosDriver.java created on 1 Fev 2013
 *
 * Copyright 2009 Linkare TI. All rights reserved.
 * Linkare TI PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package pt.utl.ist.elab.driver.worldpendulum;

import pt.utl.ist.elab.driver.serial.serialportgeneric.genericexperiment.GenericSerialPortDriver;

/**
 * 
 * @author npadriano
 */
public class WorldPendulumDriver extends GenericSerialPortDriver {

}
