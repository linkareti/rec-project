The customizer's code for this experiment. You may extend
the platform base code both from eLab and ReC as needed,
but the sources should be located here for build system 
correct integration.
