In this directory you should put source files for the
PIC code for this experiment controller.