In this directory you should put source files for the
basic stamp 2 code for this experiment controller.
