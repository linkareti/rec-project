In this directory you should put jar files
that should be available for both server and client parts 
builds of this specific experiment
but that aren't otherwise allready included in the base
libraries for ReC or eLab basic structures.
